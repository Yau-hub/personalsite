

function actionHtmlWindow(str) {
	new ActionHtmlWindow(str);
}
